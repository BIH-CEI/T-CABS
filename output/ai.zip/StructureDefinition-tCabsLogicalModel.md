# T-CABS Logical Model - T-CABS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **T-CABS Logical Model**

## Logical Model: T-CABS Logical Model 

| | |
| :--- | :--- |
| *Official URL*:http://t-cabs.org/StructureDefinition/tCabsLogicalModel | *Version*:0.1.0 |
| Draft as of 2025-12-09 | *Computable Name*:T_CABS_LogicalModel |

 
Comprehensive logical model for the T-CABS project covering: 
* Cross-domain entities (Patient, Organization)
* Ventilation data (Devices, DeviceMetric, Procedure, Parameters)
* Vital data (PHD devices, Parameters)
 
Mappings are provided to concrete T-CABS FHIR profiles for implementation guidance. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/t-cabs|current/StructureDefinition/tCabsLogicalModel)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-tCabsLogicalModel.csv), [Excel](StructureDefinition-tCabsLogicalModel.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "tCabsLogicalModel",
  "url" : "http://t-cabs.org/StructureDefinition/tCabsLogicalModel",
  "version" : "0.1.0",
  "name" : "T_CABS_LogicalModel",
  "title" : "T-CABS Logical Model",
  "status" : "draft",
  "date" : "2025-12-09T09:55:43+01:00",
  "publisher" : "BIH-CEI",
  "contact" : [
    {
      "name" : "BIH-CEI",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.bihealth.org/"
        }
      ]
    }
  ],
  "description" : "Comprehensive logical model for the T-CABS project covering:\n- Cross-domain entities (Patient, Organization)\n- Ventilation data (Devices, DeviceMetric, Procedure, Parameters)\n- Vital data (PHD devices, Parameters)\n\nMappings are provided to concrete T-CABS FHIR profiles for implementation guidance.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DE",
          "display" : "Germany"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "http://t-cabs.org/StructureDefinition/tCabsLogicalModel",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [
      {
        "id" : "tCabsLogicalModel",
        "path" : "tCabsLogicalModel",
        "short" : "T-CABS Logical Model",
        "definition" : "Comprehensive logical model for the T-CABS project covering:\n- Cross-domain entities (Patient, Organization)\n- Ventilation data (Devices, DeviceMetric, Procedure, Parameters)\n- Vital data (PHD devices, Parameters)\n\nMappings are provided to concrete T-CABS FHIR profiles for implementation guidance."
      },
      {
        "id" : "tCabsLogicalModel.crossDomain",
        "path" : "tCabsLogicalModel.crossDomain",
        "short" : "Cross-Domain Entities",
        "definition" : "Organizational and clinical context entities used across all domains",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient",
        "path" : "tCabsLogicalModel.crossDomain.patient",
        "short" : "Ventilation Patient",
        "definition" : "Patient receiving home ventilation therapy",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.identifier",
        "path" : "tCabsLogicalModel.crossDomain.patient.identifier",
        "short" : "Identifier",
        "definition" : "Unique identifier in the T-CABS study",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.name",
        "path" : "tCabsLogicalModel.crossDomain.patient.name",
        "short" : "Full Name",
        "definition" : "Complete patient name",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.gender",
        "path" : "tCabsLogicalModel.crossDomain.patient.gender",
        "short" : "Gender",
        "definition" : "Administrative gender (male|female|other|unknown)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.birthDate",
        "path" : "tCabsLogicalModel.crossDomain.patient.birthDate",
        "short" : "Birth Date",
        "definition" : "Date of birth for age calculation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "date"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.address",
        "path" : "tCabsLogicalModel.crossDomain.patient.address",
        "short" : "Home Address",
        "definition" : "Residential address for home care",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.managingOrganization",
        "path" : "tCabsLogicalModel.crossDomain.patient.managingOrganization",
        "short" : "Managing Organization",
        "definition" : "Primary healthcare organization",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.patient.generalPractitioner",
        "path" : "tCabsLogicalModel.crossDomain.patient.generalPractitioner",
        "short" : "General Practitioner",
        "definition" : "Primary care physician reference",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Practitioner"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization",
        "path" : "tCabsLogicalModel.crossDomain.organization",
        "short" : "Healthcare Organization",
        "definition" : "Treatment centers, device providers, service organizations",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization.name",
        "path" : "tCabsLogicalModel.crossDomain.organization.name",
        "short" : "Organization Name",
        "definition" : "Official name of organization",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization.identifier",
        "path" : "tCabsLogicalModel.crossDomain.organization.identifier",
        "short" : "Organization Identifier",
        "definition" : "Unique organizational identifier",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization.type",
        "path" : "tCabsLogicalModel.crossDomain.organization.type",
        "short" : "Organization Type",
        "definition" : "Healthcare provider, device manufacturer, service provider",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization.contactInfo",
        "path" : "tCabsLogicalModel.crossDomain.organization.contactInfo",
        "short" : "Contact Information",
        "definition" : "Phone, email, address for coordination",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.crossDomain.organization.providerType",
        "path" : "tCabsLogicalModel.crossDomain.organization.providerType",
        "short" : "Provider Type",
        "definition" : "Jochum|Löwenstein|Vivisol|Doccla|CABS",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData",
        "path" : "tCabsLogicalModel.ventilationData",
        "short" : "Ventilation Data",
        "definition" : "All ventilation-related devices and measurements",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices",
        "path" : "tCabsLogicalModel.ventilationData.devices",
        "short" : "Ventilation Devices",
        "definition" : "IEEE 11073 device hierarchy for ventilation monitoring",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds",
        "short" : "Medical Device System (MDS)",
        "definition" : "Top-level ventilator device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.deviceIdentifier",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.deviceIdentifier",
        "short" : "Device Identifier",
        "definition" : "UDI or unique device identification",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.manufacturer",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Device manufacturer (BREAS, ResMed, Löwenstein)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.model",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.model",
        "short" : "Device Model",
        "definition" : "Specific model designation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.serialNumber",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique device serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.deviceName",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.deviceName",
        "short" : "Device Name",
        "definition" : "Human-readable device name",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.operatingHours",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.operatingHours",
        "short" : "Operating Hours",
        "definition" : "Total device operating hours",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.patient",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.mds.owner",
        "path" : "tCabsLogicalModel.ventilationData.devices.mds.owner",
        "short" : "Device Owner",
        "definition" : "Organization owning the device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.vmd",
        "path" : "tCabsLogicalModel.ventilationData.devices.vmd",
        "short" : "Virtual Medical Device (VMD)",
        "definition" : "Parameter-specific virtual subsystems",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.vmd.vmdType",
        "path" : "tCabsLogicalModel.ventilationData.devices.vmd.vmdType",
        "short" : "VMD Type",
        "definition" : "Type of virtual medical device module",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.vmd.parameters",
        "path" : "tCabsLogicalModel.ventilationData.devices.vmd.parameters",
        "short" : "Monitored Parameters",
        "definition" : "Parameters handled by this VMD",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.vmd.manufacturer",
        "path" : "tCabsLogicalModel.ventilationData.devices.vmd.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Corresponds to MDS manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.vmd.parentMds",
        "path" : "tCabsLogicalModel.ventilationData.devices.vmd.parentMds",
        "short" : "Parent MDS",
        "definition" : "Reference to parent Medical Device System",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.channel",
        "path" : "tCabsLogicalModel.ventilationData.devices.channel",
        "short" : "Measurement Channel",
        "definition" : "Grouping of related measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.channel.channelType",
        "path" : "tCabsLogicalModel.ventilationData.devices.channel.channelType",
        "short" : "Channel Type",
        "definition" : "Type of measurement channel",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.channel.ieeeCode",
        "path" : "tCabsLogicalModel.ventilationData.devices.channel.ieeeCode",
        "short" : "IEEE 11073 Code",
        "definition" : "Standard device channel code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.devices.channel.parentVmd",
        "path" : "tCabsLogicalModel.ventilationData.devices.channel.parentVmd",
        "short" : "Parent VMD",
        "definition" : "Reference to parent Virtual Medical Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric",
        "short" : "Device Metric",
        "definition" : "Individual measurement/calculation metrics",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.metricType",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.metricType",
        "short" : "Metric Type",
        "definition" : "IEEE 11073 code for specific metric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.unit",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.category",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.category",
        "short" : "Metric Category",
        "definition" : "measurement, calculation, setting",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.operationalStatus",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.operationalStatus",
        "short" : "Operational Status",
        "definition" : "on, off, standby, not-available",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.measurementPeriod",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.measurementPeriod",
        "short" : "Measurement Period",
        "definition" : "Frequency of measurements",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.calibration",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.calibration",
        "short" : "Calibration Information",
        "definition" : "Device calibration details",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.parentChannel",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.parentChannel",
        "short" : "Parent Channel",
        "definition" : "Reference to parent measurement channel",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.deviceMetric.sourceMds",
        "path" : "tCabsLogicalModel.ventilationData.deviceMetric.sourceMds",
        "short" : "Source MDS",
        "definition" : "Reference to originating MDS device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure",
        "path" : "tCabsLogicalModel.ventilationData.procedure",
        "short" : "Ventilation Procedure",
        "definition" : "Active ventilation treatment",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.procedureCode",
        "path" : "tCabsLogicalModel.ventilationData.procedure.procedureCode",
        "short" : "Procedure Code",
        "definition" : "SNOMED CT code for ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.ventilationForm",
        "path" : "tCabsLogicalModel.ventilationData.procedure.ventilationForm",
        "short" : "Ventilation Form",
        "definition" : "Invasive or non-invasive ventilation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.ventilationMode",
        "path" : "tCabsLogicalModel.ventilationData.procedure.ventilationMode",
        "short" : "Ventilation Mode",
        "definition" : "PCV, PSV, CPAP, BiPAP (IEEE 11073 codes)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.ventilationSite",
        "path" : "tCabsLogicalModel.ventilationData.procedure.ventilationSite",
        "short" : "Ventilation Site",
        "definition" : "Tracheostomy, mask, nasal",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.performedPeriod",
        "path" : "tCabsLogicalModel.ventilationData.procedure.performedPeriod",
        "short" : "Procedure Period",
        "definition" : "Duration of ventilation treatment",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.usedDevice",
        "path" : "tCabsLogicalModel.ventilationData.procedure.usedDevice",
        "short" : "Used Device",
        "definition" : "Reference to ventilator device",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.procedure.subject",
        "path" : "tCabsLogicalModel.ventilationData.procedure.subject",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter",
        "short" : "Ventilation Parameters",
        "definition" : "Simple ventilation parameters without components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter",
        "short" : "Abstract Ventilation Parameter",
        "definition" : "Common structure for all simple ventilation measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.parameterType",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "IEEE 11073 MDC code identifying the parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.parameterName",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.value",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.value",
        "short" : "Measured Value",
        "definition" : "Numeric measurement value",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.unit",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.measurementTime",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.deviceReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.deviceReference",
        "short" : "Device Reference",
        "definition" : "Reference to associated DeviceMetric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceMetric"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.patientReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.procedureReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.procedureReference",
        "short" : "Procedure Reference",
        "definition" : "Reference to ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.category",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.category",
        "short" : "Parameter Category",
        "definition" : "procedure (from RuleSet ProcedureParameter)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.referenceRange",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.referenceRange",
        "short" : "Reference Range",
        "definition" : "Normal range for this parameter",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.measurementMethod",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.abstractParameter.measurementMethod",
        "short" : "Measurement Method",
        "definition" : "How the parameter was determined",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.ahi",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.ahi",
        "short" : "AHI (Apnea-Hypopnea Index)",
        "definition" : "Number of breathing interruptions per hour [score]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.leakage",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.leakage",
        "short" : "Leakage",
        "definition" : "System leak rate [L/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.triggeredBreaths",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.triggeredBreaths",
        "short" : "Triggered Breaths",
        "definition" : "Percentage of patient-initiated breaths [%]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.respiratoryRateVentilator",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.respiratoryRateVentilator",
        "short" : "Respiratory Rate (Ventilator)",
        "definition" : "Ventilator-measured breathing rate [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.minuteVolume",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.minuteVolume",
        "short" : "Minute Volume (AMV)",
        "definition" : "Total ventilation per minute [L/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.targetVolume",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.targetVolume",
        "short" : "Target Volume",
        "definition" : "Targeted tidal volume [mL]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.ipap",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.ipap",
        "short" : "IPAP (Inspiratory Positive Airway Pressure)",
        "definition" : "Inspiratory pressure [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.peep",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.peep",
        "short" : "PEEP (Positive End-Expiratory Pressure)",
        "definition" : "End-expiratory pressure [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameter.inspiratoryTime",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameter.inspiratoryTime",
        "short" : "Inspiratory Time (TI)",
        "definition" : "Duration of inspiration phase [s]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents",
        "short" : "Component-Based Ventilation Parameters",
        "definition" : "Parameters with multiple measurement components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam",
        "short" : "Abstract Component-Based Parameter",
        "definition" : "Common structure for compound ventilation parameters",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.parameterType",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.parameterType",
        "short" : "Parameter Type",
        "definition" : "IEEE 11073 MDC code for compound parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.parameterName",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable compound parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components",
        "short" : "Parameter Components",
        "definition" : "Individual components of compound measurement",
        "min" : 2,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentCode",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentCode",
        "short" : "Component Code",
        "definition" : "IEEE 11073 code for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentName",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentName",
        "short" : "Component Name",
        "definition" : "Human-readable component name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentValue",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentValue",
        "short" : "Component Value",
        "definition" : "Numeric value of component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentUnit",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.components.componentUnit",
        "short" : "Component Unit",
        "definition" : "UCUM unit for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.measurementTime",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.deviceReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.deviceReference",
        "short" : "Device Reference",
        "definition" : "Reference to associated DeviceMetric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceMetric"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.patientReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.procedureReference",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.procedureReference",
        "short" : "Procedure Reference",
        "definition" : "Reference to ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.category",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.abstractComponentParam.category",
        "short" : "Parameter Category",
        "definition" : "procedure (from RuleSet ProcedureParameter)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.respiratoryTimeRatio",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.respiratoryTimeRatio",
        "short" : "Respiratory Time Ratio",
        "definition" : "I:E ratio (components: inspiratory time, expiratory time)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.pressureMinMax",
        "path" : "tCabsLogicalModel.ventilationData.ventilationParameterComponents.pressureMinMax",
        "short" : "Pressure Min/Max",
        "definition" : "Pressure range (components: MinPress, MaxPress) [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData",
        "path" : "tCabsLogicalModel.vitalData",
        "short" : "Vital Data",
        "definition" : "All vital parameter devices and measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices",
        "path" : "tCabsLogicalModel.vitalData.devices",
        "short" : "Personal Health Devices",
        "definition" : "PHD hierarchy for vital parameter monitoring",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg",
        "path" : "tCabsLogicalModel.vitalData.devices.phg",
        "short" : "Personal Health Gateway (PHG)",
        "definition" : "Gateway device for data aggregation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.deviceIdentifier",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.deviceIdentifier",
        "short" : "Gateway Identifier",
        "definition" : "Unique identifier for gateway device",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.deviceType",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.deviceType",
        "short" : "Gateway Type",
        "definition" : "IEEE 11073 code for gateway type (typically tablet)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.manufacturer",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Gateway device manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.model",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.model",
        "short" : "Gateway Model",
        "definition" : "Model designation of gateway",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.serialNumber",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique gateway serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.supportedProfiles",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.supportedProfiles",
        "short" : "Supported Profiles",
        "definition" : "List of supported IEEE 11073 profiles",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phg.patient",
        "path" : "tCabsLogicalModel.vitalData.devices.phg.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this gateway",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd",
        "path" : "tCabsLogicalModel.vitalData.devices.phd",
        "short" : "Personal Health Device (PHD)",
        "definition" : "Individual measurement devices",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.deviceIdentifier",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.deviceIdentifier",
        "short" : "Device Identifier",
        "definition" : "Unique identifier for PHD",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.deviceType",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.deviceType",
        "short" : "Device Type",
        "definition" : "Type from T-CABS PHD ValueSet",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.specialization",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.specialization",
        "short" : "Device Specialization",
        "definition" : "IEEE 11073 specialization code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.manufacturer",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.manufacturer",
        "short" : "Manufacturer",
        "definition" : "PHD manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.model",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.model",
        "short" : "Device Model",
        "definition" : "Model designation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.serialNumber",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique device serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.measurementCapabilities",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.measurementCapabilities",
        "short" : "Measurement Capabilities",
        "definition" : "Types of measurements this device can perform",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.patient",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.owner",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.owner",
        "short" : "Device Owner",
        "definition" : "Organization owning the device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.devices.phd.parentGateway",
        "path" : "tCabsLogicalModel.vitalData.devices.phd.parentGateway",
        "short" : "Parent Gateway",
        "definition" : "Associated PHG for data transmission",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter",
        "short" : "Vital Parameters",
        "definition" : "Simple vital parameters without components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam",
        "short" : "Abstract Vital Parameter",
        "definition" : "Common structure for all simple vital sign measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterType",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterType",
        "short" : "Parameter Type",
        "definition" : "LOINC code identifying the vital parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterTypeMDC",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterTypeMDC",
        "short" : "Parameter Type (MDC)",
        "definition" : "IEEE 11073 MDC code for device compatibility",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterName",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.value",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.value",
        "short" : "Measured Value",
        "definition" : "Numeric measurement value",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.unit",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.measurementTime",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.deviceReference",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.deviceReference",
        "short" : "PHD Device Reference",
        "definition" : "Reference to Personal Health Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.gatewayReference",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.gatewayReference",
        "short" : "Gateway Reference",
        "definition" : "Reference to PHG gateway device",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.patientReference",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.performer",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.performer",
        "short" : "Measurement Performer",
        "definition" : "Who performed the measurement",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/StructureDefinition/Practitioner",
              "http://hl7.org/fhir/StructureDefinition/Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson"
            ]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.category",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.category",
        "short" : "Parameter Categories",
        "definition" : "vital-signs + phd-observation (PHD standard)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.referenceRange",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.abstractVitalParam.referenceRange",
        "short" : "Reference Range",
        "definition" : "Normal range for this parameter",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.heartRate",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.heartRate",
        "short" : "Heart Rate",
        "definition" : "Heart beats per minute [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.respiratoryRate",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.respiratoryRate",
        "short" : "Respiratory Rate",
        "definition" : "Spontaneous breathing rate [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.oxygenSaturation",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.oxygenSaturation",
        "short" : "Oxygen Saturation (SpO2)",
        "definition" : "Arterial oxygen saturation [%]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.bodyTemperature",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.bodyTemperature",
        "short" : "Body Temperature",
        "definition" : "Core body temperature [°C]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.bodyWeight",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.bodyWeight",
        "short" : "Body Weight",
        "definition" : "Patient weight [kg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.bmi",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.bmi",
        "short" : "Body Mass Index (BMI)",
        "definition" : "Weight-to-height ratio [kg/m²]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.walkingDistance",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.walkingDistance",
        "short" : "6-Minute Walk Distance",
        "definition" : "Distance walked in 6 minutes [m]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.handGripStrength",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.handGripStrength",
        "short" : "Hand Grip Strength",
        "definition" : "Maximum grip strength [kg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.fev1",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.fev1",
        "short" : "FEV1 (Forced Expiratory Volume 1s)",
        "definition" : "Forced expiratory volume in 1 second [L]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.fev6",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.fev6",
        "short" : "FEV6 (Forced Expiratory Volume 6s)",
        "definition" : "Forced expiratory volume in 6 seconds [L]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameter.fefTwentyFiveToSeventyFive",
        "path" : "tCabsLogicalModel.vitalData.vitalParameter.fefTwentyFiveToSeventyFive",
        "short" : "FEF25-75 (Forced Expiratory Flow)",
        "definition" : "Mean forced expiratory flow 25-75% [L/s]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents",
        "short" : "Component-Based Vital Parameters",
        "definition" : "Vital parameters with multiple measurement components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter",
        "short" : "Abstract Component-Based Vital Parameter",
        "definition" : "Common structure for compound vital parameters",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.parameterType",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "LOINC code for compound vital parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.parameterName",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable compound parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components",
        "short" : "Parameter Components",
        "definition" : "Individual components of compound measurement",
        "min" : 2,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentCode",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentCode",
        "short" : "Component Code",
        "definition" : "LOINC code for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentName",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentName",
        "short" : "Component Name",
        "definition" : "Human-readable component name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentValue",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentValue",
        "short" : "Component Value",
        "definition" : "Numeric value of component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentUnit",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentUnit",
        "short" : "Component Unit",
        "definition" : "UCUM unit for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.measurementTime",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.deviceReference",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.deviceReference",
        "short" : "PHD Device Reference",
        "definition" : "Reference to Personal Health Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.patientReference",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.abstractComponentParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.bloodPressure",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.bloodPressure",
        "short" : "Arterial Blood Pressure",
        "definition" : "Blood pressure (components: systolic, diastolic, mean) [mmHg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "tCabsLogicalModel.vitalData.vitalParameterComponents.fevOneToSixRatio",
        "path" : "tCabsLogicalModel.vitalData.vitalParameterComponents.fevOneToSixRatio",
        "short" : "FEV1/FEV6 Ratio",
        "definition" : "Pulmonary function ratio (components: FEV1, FEV6)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      }
    ]
  }
}

```
