# T-CABS Logical Model - T-CABS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **T-CABS Logical Model**

## Logical Model: T-CABS Logical Model 

| | |
| :--- | :--- |
| *Official URL*:https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-logical-model | *Version*:0.1.0 |
| Draft as of 2026-02-19 | *Computable Name*:T_CABS_LogicalModel |

 
Comprehensive logical model for the T-CABS project covering: 
* Cross-domain entities (Patient, Organization)
* Ventilation data (Devices, DeviceMetric, Procedure, Parameters)
* Vital data (PHD devices, Parameters)
 
Mappings are provided to concrete T-CABS FHIR profiles for implementation guidance. 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/t-cabs|current/StructureDefinition/t-cabs-logical-model)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](StructureDefinition-t-cabs-logical-model.csv), [Excel](StructureDefinition-t-cabs-logical-model.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "t-cabs-logical-model",
  "url" : "https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-logical-model",
  "version" : "0.1.0",
  "name" : "T_CABS_LogicalModel",
  "title" : "T-CABS Logical Model",
  "status" : "draft",
  "date" : "2026-02-19T13:21:58+01:00",
  "publisher" : "BIH-CEI",
  "contact" : [
    {
      "name" : "BIH-CEI",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.bihealth.org/"
        }
      ]
    }
  ],
  "description" : "Comprehensive logical model for the T-CABS project covering:\n- Cross-domain entities (Patient, Organization)\n- Ventilation data (Devices, DeviceMetric, Procedure, Parameters)\n- Vital data (PHD devices, Parameters)\n\nMappings are provided to concrete T-CABS FHIR profiles for implementation guidance.",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DE",
          "display" : "Germany"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-logical-model",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base",
  "derivation" : "specialization",
  "differential" : {
    "element" : [
      {
        "id" : "t-cabs-logical-model",
        "path" : "t-cabs-logical-model",
        "short" : "T-CABS Logical Model",
        "definition" : "Comprehensive logical model for the T-CABS project covering:\n- Cross-domain entities (Patient, Organization)\n- Ventilation data (Devices, DeviceMetric, Procedure, Parameters)\n- Vital data (PHD devices, Parameters)\n\nMappings are provided to concrete T-CABS FHIR profiles for implementation guidance."
      },
      {
        "id" : "t-cabs-logical-model.crossDomain",
        "path" : "t-cabs-logical-model.crossDomain",
        "short" : "Cross-Domain Entities",
        "definition" : "Organizational and clinical context entities used across all domains",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient",
        "path" : "t-cabs-logical-model.crossDomain.patient",
        "short" : "Ventilation Patient",
        "definition" : "Patient receiving home ventilation therapy",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.identifier",
        "path" : "t-cabs-logical-model.crossDomain.patient.identifier",
        "short" : "Identifier",
        "definition" : "Unique identifier in the T-CABS study",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.name",
        "path" : "t-cabs-logical-model.crossDomain.patient.name",
        "short" : "Full Name",
        "definition" : "Complete patient name",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.gender",
        "path" : "t-cabs-logical-model.crossDomain.patient.gender",
        "short" : "Gender",
        "definition" : "Administrative gender (male|female|other|unknown)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.birthDate",
        "path" : "t-cabs-logical-model.crossDomain.patient.birthDate",
        "short" : "Birth Date",
        "definition" : "Date of birth for age calculation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "date"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.address",
        "path" : "t-cabs-logical-model.crossDomain.patient.address",
        "short" : "Home Address",
        "definition" : "Residential address for home care",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.managingOrganization",
        "path" : "t-cabs-logical-model.crossDomain.patient.managingOrganization",
        "short" : "Managing Organization",
        "definition" : "Primary healthcare organization",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.patient.generalPractitioner",
        "path" : "t-cabs-logical-model.crossDomain.patient.generalPractitioner",
        "short" : "General Practitioner",
        "definition" : "Primary care physician reference",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Practitioner"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization",
        "path" : "t-cabs-logical-model.crossDomain.organization",
        "short" : "Healthcare Organization",
        "definition" : "Treatment centers, device providers, service organizations",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization.name",
        "path" : "t-cabs-logical-model.crossDomain.organization.name",
        "short" : "Organization Name",
        "definition" : "Official name of organization",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization.identifier",
        "path" : "t-cabs-logical-model.crossDomain.organization.identifier",
        "short" : "Organization Identifier",
        "definition" : "Unique organizational identifier",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization.type",
        "path" : "t-cabs-logical-model.crossDomain.organization.type",
        "short" : "Organization Type",
        "definition" : "Healthcare provider, device manufacturer, service provider",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization.contactInfo",
        "path" : "t-cabs-logical-model.crossDomain.organization.contactInfo",
        "short" : "Contact Information",
        "definition" : "Phone, email, address for coordination",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.crossDomain.organization.providerType",
        "path" : "t-cabs-logical-model.crossDomain.organization.providerType",
        "short" : "Provider Type",
        "definition" : "Jochum|Löwenstein|Vivisol|Doccla|CABS",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData",
        "path" : "t-cabs-logical-model.ventilationData",
        "short" : "Ventilation Data",
        "definition" : "All ventilation-related devices and measurements",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices",
        "path" : "t-cabs-logical-model.ventilationData.devices",
        "short" : "Ventilation Devices",
        "definition" : "IEEE 11073 device hierarchy for ventilation monitoring",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds",
        "short" : "Medical Device System (MDS)",
        "definition" : "Top-level ventilator device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.deviceIdentifier",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.deviceIdentifier",
        "short" : "Device Identifier",
        "definition" : "UDI or unique device identification",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.manufacturer",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Device manufacturer (BREAS, ResMed, Löwenstein)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.model",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.model",
        "short" : "Device Model",
        "definition" : "Specific model designation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.serialNumber",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique device serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.deviceName",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.deviceName",
        "short" : "Device Name",
        "definition" : "Human-readable device name",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.operatingHours",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.operatingHours",
        "short" : "Operating Hours",
        "definition" : "Total device operating hours",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.patient",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.mds.owner",
        "path" : "t-cabs-logical-model.ventilationData.devices.mds.owner",
        "short" : "Device Owner",
        "definition" : "Organization owning the device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.vmd",
        "path" : "t-cabs-logical-model.ventilationData.devices.vmd",
        "short" : "Virtual Medical Device (VMD)",
        "definition" : "Parameter-specific virtual subsystems",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.vmd.vmdType",
        "path" : "t-cabs-logical-model.ventilationData.devices.vmd.vmdType",
        "short" : "VMD Type",
        "definition" : "Type of virtual medical device module",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.vmd.parameters",
        "path" : "t-cabs-logical-model.ventilationData.devices.vmd.parameters",
        "short" : "Monitored Parameters",
        "definition" : "Parameters handled by this VMD",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.vmd.manufacturer",
        "path" : "t-cabs-logical-model.ventilationData.devices.vmd.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Corresponds to MDS manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.vmd.parentMds",
        "path" : "t-cabs-logical-model.ventilationData.devices.vmd.parentMds",
        "short" : "Parent MDS",
        "definition" : "Reference to parent Medical Device System",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.channel",
        "path" : "t-cabs-logical-model.ventilationData.devices.channel",
        "short" : "Measurement Channel",
        "definition" : "Grouping of related measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.channel.channelType",
        "path" : "t-cabs-logical-model.ventilationData.devices.channel.channelType",
        "short" : "Channel Type",
        "definition" : "Type of measurement channel",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.channel.ieeeCode",
        "path" : "t-cabs-logical-model.ventilationData.devices.channel.ieeeCode",
        "short" : "IEEE 11073 Code",
        "definition" : "Standard device channel code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.devices.channel.parentVmd",
        "path" : "t-cabs-logical-model.ventilationData.devices.channel.parentVmd",
        "short" : "Parent VMD",
        "definition" : "Reference to parent Virtual Medical Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric",
        "short" : "Device Metric",
        "definition" : "Individual measurement/calculation metrics",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.metricType",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.metricType",
        "short" : "Metric Type",
        "definition" : "IEEE 11073 code for specific metric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.unit",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.category",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.category",
        "short" : "Metric Category",
        "definition" : "measurement, calculation, setting",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.operationalStatus",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.operationalStatus",
        "short" : "Operational Status",
        "definition" : "on, off, standby, not-available",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.measurementPeriod",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.measurementPeriod",
        "short" : "Measurement Period",
        "definition" : "Frequency of measurements",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.calibration",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.calibration",
        "short" : "Calibration Information",
        "definition" : "Device calibration details",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.parentChannel",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.parentChannel",
        "short" : "Parent Channel",
        "definition" : "Reference to parent measurement channel",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.deviceMetric.sourceMds",
        "path" : "t-cabs-logical-model.ventilationData.deviceMetric.sourceMds",
        "short" : "Source MDS",
        "definition" : "Reference to originating MDS device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure",
        "path" : "t-cabs-logical-model.ventilationData.procedure",
        "short" : "Ventilation Procedure",
        "definition" : "Active ventilation treatment",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.procedureCode",
        "path" : "t-cabs-logical-model.ventilationData.procedure.procedureCode",
        "short" : "Procedure Code",
        "definition" : "SNOMED CT code for ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.ventilationForm",
        "path" : "t-cabs-logical-model.ventilationData.procedure.ventilationForm",
        "short" : "Ventilation Form",
        "definition" : "Invasive or non-invasive ventilation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.ventilationMode",
        "path" : "t-cabs-logical-model.ventilationData.procedure.ventilationMode",
        "short" : "Ventilation Mode",
        "definition" : "PCV, PSV, CPAP, BiPAP (IEEE 11073 codes)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.ventilationSite",
        "path" : "t-cabs-logical-model.ventilationData.procedure.ventilationSite",
        "short" : "Ventilation Site",
        "definition" : "Tracheostomy, mask, nasal",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.performedPeriod",
        "path" : "t-cabs-logical-model.ventilationData.procedure.performedPeriod",
        "short" : "Procedure Period",
        "definition" : "Duration of ventilation treatment",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.usedDevice",
        "path" : "t-cabs-logical-model.ventilationData.procedure.usedDevice",
        "short" : "Used Device",
        "definition" : "Reference to ventilator device",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.procedure.subject",
        "path" : "t-cabs-logical-model.ventilationData.procedure.subject",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter",
        "short" : "Ventilation Parameters",
        "definition" : "Simple ventilation parameters without components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter",
        "short" : "Abstract Ventilation Parameter",
        "definition" : "Common structure for all simple ventilation measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.parameterType",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "IEEE 11073 MDC code identifying the parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.parameterName",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.value",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.value",
        "short" : "Measured Value",
        "definition" : "Numeric measurement value",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.unit",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.measurementTime",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.deviceReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.deviceReference",
        "short" : "Device Reference",
        "definition" : "Reference to associated DeviceMetric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceMetric"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.patientReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.procedureReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.procedureReference",
        "short" : "Procedure Reference",
        "definition" : "Reference to ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.category",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.category",
        "short" : "Parameter Category",
        "definition" : "procedure (from RuleSet ProcedureParameter)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.referenceRange",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.referenceRange",
        "short" : "Reference Range",
        "definition" : "Normal range for this parameter",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.measurementMethod",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.abstractVentilationParameter.measurementMethod",
        "short" : "Measurement Method",
        "definition" : "How the parameter was determined",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.ahi",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.ahi",
        "short" : "AHI (Apnea-Hypopnea Index)",
        "definition" : "Number of breathing interruptions per hour [score]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.leakage",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.leakage",
        "short" : "Leakage",
        "definition" : "System leak rate [L/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.triggeredBreaths",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.triggeredBreaths",
        "short" : "Triggered Breaths",
        "definition" : "Percentage of patient-initiated breaths [%]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.respiratoryRateVentilator",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.respiratoryRateVentilator",
        "short" : "Respiratory Rate (Ventilator)",
        "definition" : "Ventilator-measured breathing rate [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.minuteVolume",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.minuteVolume",
        "short" : "Minute Volume (AMV)",
        "definition" : "Total ventilation per minute [L/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.targetVolume",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.targetVolume",
        "short" : "Target Volume",
        "definition" : "Targeted tidal volume [mL]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.ipap",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.ipap",
        "short" : "IPAP (Inspiratory Positive Airway Pressure)",
        "definition" : "Inspiratory pressure [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.peep",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.peep",
        "short" : "PEEP (Positive End-Expiratory Pressure)",
        "definition" : "End-expiratory pressure [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameter.inspiratoryTime",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameter.inspiratoryTime",
        "short" : "Inspiratory Time (TI)",
        "definition" : "Duration of inspiration phase [s]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents",
        "short" : "Component-Based Ventilation Parameters",
        "definition" : "Parameters with multiple measurement components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter",
        "short" : "Abstract Component-Based Parameter",
        "definition" : "Common structure for compound ventilation parameters",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.parameterType",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "IEEE 11073 MDC code for compound parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.parameterName",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable compound parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components",
        "short" : "Parameter Components",
        "definition" : "Individual components of compound measurement",
        "min" : 2,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentCode",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentCode",
        "short" : "Component Code",
        "definition" : "IEEE 11073 code for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentName",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentName",
        "short" : "Component Name",
        "definition" : "Human-readable component name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentValue",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentValue",
        "short" : "Component Value",
        "definition" : "Numeric value of component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentUnit",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.components.componentUnit",
        "short" : "Component Unit",
        "definition" : "UCUM unit for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.measurementTime",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.deviceReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.deviceReference",
        "short" : "Device Reference",
        "definition" : "Reference to associated DeviceMetric",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DeviceMetric"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.patientReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.procedureReference",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.procedureReference",
        "short" : "Procedure Reference",
        "definition" : "Reference to ventilation procedure",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Procedure"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.category",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.abstractComponentParameter.category",
        "short" : "Parameter Category",
        "definition" : "procedure (from RuleSet ProcedureParameter)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.respiratoryTimeRatio",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.respiratoryTimeRatio",
        "short" : "Respiratory Time Ratio",
        "definition" : "I:E ratio (components: inspiratory time, expiratory time)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.pressureMinMax",
        "path" : "t-cabs-logical-model.ventilationData.ventilationParameterComponents.pressureMinMax",
        "short" : "Pressure Min/Max",
        "definition" : "Pressure range (components: MinPress, MaxPress) [mbar]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData",
        "path" : "t-cabs-logical-model.vitalData",
        "short" : "Vital Data",
        "definition" : "All vital parameter devices and measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices",
        "path" : "t-cabs-logical-model.vitalData.devices",
        "short" : "Personal Health Devices",
        "definition" : "PHD hierarchy for vital parameter monitoring",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg",
        "path" : "t-cabs-logical-model.vitalData.devices.phg",
        "short" : "Personal Health Gateway (PHG)",
        "definition" : "Gateway device for data aggregation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.deviceIdentifier",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.deviceIdentifier",
        "short" : "Gateway Identifier",
        "definition" : "Unique identifier for gateway device",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.deviceType",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.deviceType",
        "short" : "Gateway Type",
        "definition" : "IEEE 11073 code for gateway type (typically tablet)",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.manufacturer",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.manufacturer",
        "short" : "Manufacturer",
        "definition" : "Gateway device manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.model",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.model",
        "short" : "Gateway Model",
        "definition" : "Model designation of gateway",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.serialNumber",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique gateway serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.supportedProfiles",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.supportedProfiles",
        "short" : "Supported Profiles",
        "definition" : "List of supported IEEE 11073 profiles",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phg.patient",
        "path" : "t-cabs-logical-model.vitalData.devices.phg.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this gateway",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd",
        "path" : "t-cabs-logical-model.vitalData.devices.phd",
        "short" : "Personal Health Device (PHD)",
        "definition" : "Individual measurement devices",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.deviceIdentifier",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.deviceIdentifier",
        "short" : "Device Identifier",
        "definition" : "Unique identifier for PHD",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.deviceType",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.deviceType",
        "short" : "Device Type",
        "definition" : "Type from T-CABS PHD ValueSet",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.specialization",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.specialization",
        "short" : "Device Specialization",
        "definition" : "IEEE 11073 specialization code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.manufacturer",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.manufacturer",
        "short" : "Manufacturer",
        "definition" : "PHD manufacturer",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.model",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.model",
        "short" : "Device Model",
        "definition" : "Model designation",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.serialNumber",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.serialNumber",
        "short" : "Serial Number",
        "definition" : "Unique device serial number",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.measurementCapabilities",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.measurementCapabilities",
        "short" : "Measurement Capabilities",
        "definition" : "Types of measurements this device can perform",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.patient",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.patient",
        "short" : "Patient Reference",
        "definition" : "Patient using this device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.owner",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.owner",
        "short" : "Device Owner",
        "definition" : "Organization owning the device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Organization"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.devices.phd.parentGateway",
        "path" : "t-cabs-logical-model.vitalData.devices.phd.parentGateway",
        "short" : "Parent Gateway",
        "definition" : "Associated PHG for data transmission",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter",
        "short" : "Vital Parameters",
        "definition" : "Simple vital parameters without components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter",
        "short" : "Abstract Vital Parameter",
        "definition" : "Common structure for all simple vital sign measurements",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterType",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "LOINC code identifying the vital parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterTypeMDC",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterTypeMDC",
        "short" : "Parameter Type (MDC)",
        "definition" : "IEEE 11073 MDC code for device compatibility",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterName",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.value",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.value",
        "short" : "Measured Value",
        "definition" : "Numeric measurement value",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.unit",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.unit",
        "short" : "Measurement Unit",
        "definition" : "UCUM unit code",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.measurementTime",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.deviceReference",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.deviceReference",
        "short" : "PHD Device Reference",
        "definition" : "Reference to Personal Health Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.gatewayReference",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.gatewayReference",
        "short" : "Gateway Reference",
        "definition" : "Reference to PHG gateway device",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.patientReference",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.performer",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.performer",
        "short" : "Measurement Performer",
        "definition" : "Who performed the measurement",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : [
              "http://hl7.org/fhir/StructureDefinition/Practitioner",
              "http://hl7.org/fhir/StructureDefinition/Patient",
              "http://hl7.org/fhir/StructureDefinition/RelatedPerson"
            ]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.category",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.category",
        "short" : "Parameter Categories",
        "definition" : "vital-signs + phd-observation (PHD standard)",
        "min" : 1,
        "max" : "*",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.referenceRange",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.abstractVitalParameter.referenceRange",
        "short" : "Reference Range",
        "definition" : "Normal range for this parameter",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.heartRate",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.heartRate",
        "short" : "Heart Rate",
        "definition" : "Heart beats per minute [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.respiratoryRate",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.respiratoryRate",
        "short" : "Respiratory Rate",
        "definition" : "Spontaneous breathing rate [/min]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.oxygenSaturation",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.oxygenSaturation",
        "short" : "Oxygen Saturation (SpO2)",
        "definition" : "Arterial oxygen saturation [%]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.bodyTemperature",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.bodyTemperature",
        "short" : "Body Temperature",
        "definition" : "Core body temperature [°C]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.bodyWeight",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.bodyWeight",
        "short" : "Body Weight",
        "definition" : "Patient weight [kg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.bmi",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.bmi",
        "short" : "Body Mass Index (BMI)",
        "definition" : "Weight-to-height ratio [kg/m²]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.walkingDistance",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.walkingDistance",
        "short" : "6-Minute Walk Distance",
        "definition" : "Distance walked in 6 minutes [m]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.handGripStrength",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.handGripStrength",
        "short" : "Hand Grip Strength",
        "definition" : "Maximum grip strength [kg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.fev1",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.fev1",
        "short" : "FEV1 (Forced Expiratory Volume 1s)",
        "definition" : "Forced expiratory volume in 1 second [L]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.fev6",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.fev6",
        "short" : "FEV6 (Forced Expiratory Volume 6s)",
        "definition" : "Forced expiratory volume in 6 seconds [L]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameter.fef2575",
        "path" : "t-cabs-logical-model.vitalData.vitalParameter.fef2575",
        "short" : "FEF25-75 (Forced Expiratory Flow)",
        "definition" : "Mean forced expiratory flow 25-75% [L/s]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents",
        "short" : "Component-Based Vital Parameters",
        "definition" : "Vital parameters with multiple measurement components",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter",
        "short" : "Abstract Component-Based Vital Parameter",
        "definition" : "Common structure for compound vital parameters",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.parameterType",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.parameterType",
        "short" : "Parameter Type",
        "definition" : "LOINC code for compound vital parameter",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.parameterName",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.parameterName",
        "short" : "Parameter Name",
        "definition" : "Human-readable compound parameter name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components",
        "short" : "Parameter Components",
        "definition" : "Individual components of compound measurement",
        "min" : 2,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentCode",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentCode",
        "short" : "Component Code",
        "definition" : "LOINC code for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentName",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentName",
        "short" : "Component Name",
        "definition" : "Human-readable component name",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentValue",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentValue",
        "short" : "Component Value",
        "definition" : "Numeric value of component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "decimal"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentUnit",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.components.componentUnit",
        "short" : "Component Unit",
        "definition" : "UCUM unit for component",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.measurementTime",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.measurementTime",
        "short" : "Measurement Time",
        "definition" : "Time period of measurement",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Period"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.deviceReference",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.deviceReference",
        "short" : "PHD Device Reference",
        "definition" : "Reference to Personal Health Device",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Device"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.patientReference",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.abstractComponentParameter.patientReference",
        "short" : "Patient Reference",
        "definition" : "Reference to patient",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.bloodPressure",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.bloodPressure",
        "short" : "Arterial Blood Pressure",
        "definition" : "Blood pressure (components: systolic, diastolic, mean) [mmHg]",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      },
      {
        "id" : "t-cabs-logical-model.vitalData.vitalParameterComponents.fev1fev6Ratio",
        "path" : "t-cabs-logical-model.vitalData.vitalParameterComponents.fev1fev6Ratio",
        "short" : "FEV1/FEV6 Ratio",
        "definition" : "Pulmonary function ratio (components: FEV1, FEV6)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Quantity"
          }
        ]
      }
    ]
  }
}

```
