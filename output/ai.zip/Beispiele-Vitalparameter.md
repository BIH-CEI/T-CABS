# Beispiele Vitalparameter - v0.1.0

* [**Table of Contents**](toc.md)
* **Beispiele Vitalparameter**

## Beispiele Vitalparameter

### Devices

* [PHD Device Doccla](Device-beispiel-phd-doccla.md)
* [PHG Gateway Doccla](Device-beispiel-phg-doccla.md)

### Vitalparameter-Observations

* [Arterielle Sauerstoffsättigung](Observation-Example-ArterielleSPO2-Doccla.md)
* [Arterieller Blutdruck](Observation-Example-ArteriellerBlutdruck-Doccla.md)
* [Atemfrequenz](Observation-Example-Atemfrequenz-Doccla.md)
* [BMI](Observation-Example-BMI-Doccla.md)
* [FEV1](Observation-Example-FEV1-Doccla.md)
* [Gehstrecke](Observation-Example-Gehstrecke-Doccla.md)
* [Herzfrequenz](Observation-Example-Herzfrequenz-Doccla.md)
* [Körpergewicht](Observation-Example-Koerpergewicht-Doccla.md)
* [Körpertemperatur](Observation-Example-Koerpertemperatur-Doccla.md)

