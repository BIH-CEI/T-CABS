# Example Body Weight Measurement - T-CABS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Body Weight Measurement**

## Example Observation: Example Body Weight Measurement

Profiles: [T-CABS Observation Body Weight](StructureDefinition-t-cabs-observation-koerpergewicht.md), [https://gematik.de/fhir/isik/StructureDefinition/ISiKKoerpergewicht|5.1.0](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.person@2025.0.0&canonical=https://gematik.de/fhir/isik/StructureDefinition/ISiKKoerpergewicht|5.1.0)

**Observation Gateway Device**: [Device: identifier = IEEE 11073 System Identifier; manufacturer = Doccla GmbH; serialNumber = PHG-SN-789012; modelNumber = DHT-2024; type = MDC_MOC_VMS_MDS_AHD](Device-beispiel-phg-doccla.md)

**status**: Final

**category**: Vital Signs, PHD generated Observation

**code**: Body weight

**subject**: [Max Mustermann (official) Male, DoB: 1980-01-15 ( Medical record number)](Patient-tcabs-patient-example.md)

**effective**: 2024-01-15 07:30:00+0000 --> 2024-01-15 07:30:00+0000

**value**: 75.8 kg (Details: UCUM codekg = 'kg')

**device**: [Device: identifier = IEEE 11073 System Identifier; manufacturer = Beurer; serialNumber = BEURER-SC-789012; modelNumber = BF 700; type = MDC_MOC_VMS_MDS_SIMP](Device-beispiel-phd-waage.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "Example-Koerpergewicht-Doccla",
  "meta" : {
    "profile" : [
      "https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-observation-koerpergewicht",
      "https://gematik.de/fhir/isik/StructureDefinition/ISiKKoerpergewicht|5.1.0"
    ]
  },
  "extension" : [
    {
      "url" : "http://hl7.org/fhir/StructureDefinition/observation-gatewayDevice",
      "valueReference" : {
        "reference" : "Device/beispiel-phg-doccla"
      }
    }
  ],
  "status" : "final",
  "category" : [
    {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "vital-signs"
        }
      ]
    },
    {
      "coding" : [
        {
          "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/PhdObservationCategories",
          "code" : "phd-observation"
        }
      ]
    }
  ],
  "code" : {
    "coding" : [
      {
        "system" : "http://loinc.org",
        "code" : "29463-7",
        "display" : "Body weight"
      },
      {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "188736"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/tcabs-patient-example"
  },
  "effectivePeriod" : {
    "start" : "2024-01-15T07:30:00Z",
    "end" : "2024-01-15T07:30:00Z"
  },
  "valueQuantity" : {
    "value" : 75.8,
    "unit" : "kg",
    "system" : "http://unitsofmeasure.org",
    "code" : "kg"
  },
  "device" : {
    "reference" : "Device/beispiel-phd-waage"
  }
}

```
