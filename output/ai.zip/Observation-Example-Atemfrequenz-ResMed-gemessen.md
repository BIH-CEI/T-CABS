# Example Respiratory Rate Measurement ResMed - T-CABS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example Respiratory Rate Measurement ResMed**

## Example Observation: Example Respiratory Rate Measurement ResMed

Profile: [T-CABS Observation Respiratory Rate Ventilated](StructureDefinition-t-cabs-observation-atemfrequenz-beatmet.md)

**partOf**: [Procedure MDC_PRESS_AWAY_CTS_POS](Procedure-beispiel-beatmung-resmed.md)

**status**: Final

**category**: Procedure

**code**: MDC_VENT_RESP_RATE

**subject**: [Max Mustermann (official) Male, DoB: 1980-01-15 ( Medical record number)](Patient-tcabs-patient-example.md)

**effective**: 2024-01-15 23:20:00+0000 --> 2024-01-15 23:20:00+0000

**value**: 14 /min (Details: UCUM code/min = '/min')

**device**: [DeviceMetric: identifier = http://tcabs.example.org/device-metric#DM-RESMED-ATEMFREQ-001; type = MDC_VENT_RESP_RATE; unit = /min; operationalStatus = on; color = cyan; category = measurement; measurementPeriod = Once per 1 minute](DeviceMetric-beispiel-devicemetric-resmed-atemfrequenz.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "Example-Atemfrequenz-ResMed-gemessen",
  "meta" : {
    "profile" : [
      "https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-observation-atemfrequenz-beatmet"
    ]
  },
  "partOf" : [
    {
      "reference" : "Procedure/beispiel-beatmung-resmed"
    }
  ],
  "status" : "final",
  "category" : [
    {
      "coding" : [
        {
          "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
          "code" : "procedure"
        }
      ]
    }
  ],
  "code" : {
    "coding" : [
      {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "151586",
        "display" : "MDC_VENT_RESP_RATE"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/tcabs-patient-example"
  },
  "effectivePeriod" : {
    "start" : "2024-01-15T23:20:00Z",
    "end" : "2024-01-15T23:20:00Z"
  },
  "valueQuantity" : {
    "value" : 14,
    "unit" : "/min",
    "system" : "http://unitsofmeasure.org",
    "code" : "/min"
  },
  "device" : {
    "reference" : "DeviceMetric/beispiel-devicemetric-resmed-atemfrequenz"
  }
}

```
