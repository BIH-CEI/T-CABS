# Example PHD Peak Flow Meter - T-CABS Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Example PHD Peak Flow Meter**

## Example Device: Example PHD Peak Flow Meter

Profile: [T-CABS Device PHD](StructureDefinition-t-cabs-device-phd.md)

**identifier**: IEEE 11073 System Identifier/PHD-PEAK-007

**manufacturer**: Clement Clarke

**serialNumber**: CLEMENT-PF-789012

### DeviceNames

| | | |
| :--- | :--- | :--- |
| - | **Name** | **Type** |
| * | Peak Flow Meter | User Friendly name |

**modelNumber**: Mini-Wright

**type**: MDC_MOC_VMS_MDS_SIMP

### Specializations

| | | |
| :--- | :--- | :--- |
| - | **SystemType** | **Version** |
| * | MDC_DEV_SPEC_PROFILE_PEFM | 1.0 |

**patient**: [Max Mustermann (official) Male, DoB: 1980-01-15 ( Medical record number)](Patient-tcabs-patient-example.md)

**owner**: [Organization Doccla Deutschland GmbH](Organization-beispiel-provider-doccla.md)



## Resource Content

```json
{
  "resourceType" : "Device",
  "id" : "beispiel-phd-peakflow",
  "meta" : {
    "profile" : [
      "https://bih-cei.github.io/T-CABS/StructureDefinition/t-cabs-device-phd"
    ]
  },
  "identifier" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://hl7.org/fhir/uv/phd/CodeSystem/ContinuaDeviceIdentifiers",
            "code" : "SYSID"
          }
        ]
      },
      "system" : "urn:oid:1.2.840.10004.1.1.1.0.0.1.0.0.1.2680",
      "value" : "PHD-PEAK-007"
    }
  ],
  "manufacturer" : "Clement Clarke",
  "serialNumber" : "CLEMENT-PF-789012",
  "deviceName" : [
    {
      "name" : "Peak Flow Meter",
      "type" : "user-friendly-name"
    }
  ],
  "modelNumber" : "Mini-Wright",
  "type" : {
    "coding" : [
      {
        "system" : "urn:iso:std:iso:11073:10101",
        "code" : "65573",
        "display" : "MDC_MOC_VMS_MDS_SIMP"
      }
    ]
  },
  "specialization" : [
    {
      "systemType" : {
        "coding" : [
          {
            "system" : "urn:iso:std:iso:11073:10101",
            "code" : "528405",
            "display" : "MDC_DEV_SPEC_PROFILE_PEFM"
          }
        ]
      },
      "version" : "1.0"
    }
  ],
  "patient" : {
    "reference" : "Patient/tcabs-patient-example"
  },
  "owner" : {
    "reference" : "Organization/beispiel-provider-doccla"
  }
}

```
